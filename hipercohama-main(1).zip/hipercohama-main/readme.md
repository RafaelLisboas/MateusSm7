# PDVS - 7 Hiper Cohama
 Site feito com os endereços ip's de cada pdv para acesso via HTML.